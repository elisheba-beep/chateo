import 'package:chateo/core/constants/sized_boxes.dart';
import 'package:chateo/core/router/route_names.dart';
import 'package:chateo/core/theme/app_text_styles.dart';
import 'package:chateo/core/widgets/button/chateo_button.dart';
import 'package:material_ui/material_ui.dart';
import 'package:go_router/go_router.dart';

class WalkthroughScreen extends StatelessWidget {
  const new({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Center(
                child: Image(
                  image: AssetImage('assets/images/chateo_onboarding.png'),
                ),
              ),
              42.heightBox,
              Text(
                'Connect easily with your family and friends over countries',
                style: AppTextStyles.heading2,
              ),
              Spacer(),
              Text(
                'Terms & Privacy Policy',
                style: AppTextStyles.bodyTextSmall,
              ),
              18.heightBox,
              ChateoButton(
                text: 'Start Messaging',
                onPressed: () {
                  context.goNamed(RouteNames.phoneNumberInput);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
