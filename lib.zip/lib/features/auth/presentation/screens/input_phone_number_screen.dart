import 'package:chateo/core/constants/sized_boxes.dart';
import 'package:chateo/core/providers/selected_country_provider.dart';
import 'package:chateo/core/router/route_names.dart';
import 'package:chateo/core/theme/app_text_styles.dart';
import 'package:chateo/core/widgets/button/chateo_button.dart';
import 'package:chateo/features/auth/presentation/providers/phone_auth_provider.dart';
import 'package:chateo/features/auth/presentation/widgets/chateo_registration_phone_picker.dart';
import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

class InputPhoneNumberScreen extends ConsumerStatefulWidget {
  const InputPhoneNumberScreen({super.key});

  @override
  ConsumerState<InputPhoneNumberScreen> createState() =>
      _InputPhoneNumberScreenState();
}

class _InputPhoneNumberScreenState
    extends ConsumerState<InputPhoneNumberScreen> {
  final _phone = TextEditingController();

  @override
  void dispose() {
    _phone.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    ref.listen(phoneAuthProvider, (prev, next) {
      if (next.error != null && next.error != prev?.error) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(next.error!)));
      }
      if (prev?.status != PhoneAuthStatus.codeSent &&
          next.status == PhoneAuthStatus.codeSent) {
        context.pushNamed(RouteNames.verificationCodeInput);
      }
    });

    final country = ref.watch(selectedCountryProvider);
    final auth = ref.watch(phoneAuthProvider);

    return Scaffold(
      appBar: AppBar(),
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverFillRemaining(
              hasScrollBody: false,
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Enter Your Phone Number',
                      style: AppTextStyles.heading2,
                    ),
                    8.heightBox,
                    Text(
                      'Please confirm your country code and enter your phone number',
                      style: AppTextStyles.bodyTextSmall,
                    ),
                    48.heightBox,
                    ChateoRegistrationPhonePicker(
                      country: country,
                      controller: _phone,
                      onCountryTap: () async {
                        final picked = await showCountryPicker(
                          context,
                          country,
                        );
                        if (!mounted || picked == null) {
                          return;
                        }
                        ref
                            .read(selectedCountryProvider.notifier)
                            .select(picked);
                      },
                    ),
                    const Spacer(),
                    ChateoButton(
                      text: 'Continue',
                      isLoading: auth.isLoading,
                      onPressed: auth.isLoading
                          ? null
                          : () => ref
                                .read(phoneAuthProvider.notifier)
                                .sendCode(country, _phone.text),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
