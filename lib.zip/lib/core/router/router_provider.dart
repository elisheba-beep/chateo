import 'dart:async';

import 'package:chateo/core/providers/firebase_providers.dart';
import 'package:chateo/core/router/route_names.dart';
import 'package:chateo/core/widgets/page_not_found/page_not_found.dart';
import 'package:chateo/features/auth/presentation/screens/input_phone_number_screen.dart';
import 'package:chateo/features/auth/presentation/screens/input_verification_code_screen.dart';
import 'package:chateo/features/auth/presentation/screens/profile_registration_screen.dart';
import 'package:chateo/features/onboarding/presentation/screens/walkthrough_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:material_ui/material_ui.dart';
import 'package:go_router/go_router.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

part 'router_provider.g.dart';

class _AuthRefresh extends ChangeNotifier {
  _AuthRefresh(Stream<User?> stream) {
    _sub = stream.listen((_) => notifyListeners());
  }

  late final StreamSubscription<User?> _sub;

  @override
  void dispose() {
    _sub.cancel();
    super.dispose();
  }
}

@riverpod
GoRouter router(Ref ref) {
  final auth = ref.watch(firebaseAuthProvider);
  final refresh = _AuthRefresh(auth.authStateChanges());
  ref.onDispose(refresh.dispose);

  return GoRouter(
    initialLocation: '/walkthrough',
    refreshListenable: refresh,
    redirect: (context, state) {
      final signedIn = auth.currentUser != null;
      final loc = state.matchedLocation;
      const authFlow = {
        '/walkthrough',
        '/phoneNumberInput',
        '/verificationCodeInput',
      };

      if (signedIn && authFlow.contains(loc)) {
        return '/profileRegistration';
      }
      if (!signedIn && loc == '/profileRegistration') {
        return '/phoneNumberInput';
      }
      return null;
    },
    routes: [
      GoRoute(
        path: '/walkthrough',
        name: RouteNames.walkthrough,
        builder: (context, state) => const WalkthroughScreen(),
      ),
      GoRoute(
        path: '/phoneNumberInput',
        name: RouteNames.phoneNumberInput,
        builder: (context, state) => const InputPhoneNumberScreen(),
      ),
      GoRoute(
        path: '/verificationCodeInput',
        name: RouteNames.verificationCodeInput,
        builder: (context, state) => const InputVerificationCodeScreen(),
      ),
      GoRoute(
        path: '/profileRegistration',
        name: RouteNames.profileRegistration,
        builder: (context, state) => const ProfileRegistrationScreen(),
      ),
    ],
    errorBuilder: (context, state) =>
        PageNotFound(errorMessage: state.error.toString()),
  );
}
